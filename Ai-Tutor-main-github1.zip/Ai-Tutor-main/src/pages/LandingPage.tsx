import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Moon, Sun } from 'lucide-react';
import StudyScene from '../components/StudyScene';
import FeatureSection from '../components/FeatureSection';
import RoadmapSection from '../components/RoadmapSection';
import Footer from '../components/Footer';

export default function LandingPage() {
  const navigate = useNavigate();
  const [isDark, setIsDark] = useState(false);

  // Check system preference and saved preference
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const enabled = savedTheme === 'dark' || (!savedTheme && systemPrefersDark);

    if (enabled) {
      document.documentElement.classList.add('dark');
      setIsDark(true);
    } else {
      document.documentElement.classList.remove('dark');
      setIsDark(false);
    }
  }, []);

  const handleThemeToggle = () => {
    const html = document.documentElement;
    const newTheme = !isDark;
    html.classList.toggle('dark');
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    setIsDark(newTheme);
  };

  return (
    <div className="relative w-full min-h-screen bg-gradient-to-br from-[#ecf7ff] to-[#fff8fc] dark:from-[#0f172a] dark:to-[#1e293b] overflow-x-hidden">
      <StudyScene />

      {/* Dark Mode Toggle */}
      <button
        onClick={handleThemeToggle}
        className="fixed top-4 right-4 z-50 bg-white/80 dark:bg-gray-800 text-black dark:text-white px-3 py-2 rounded-full shadow-md hover:scale-105 transition"
        aria-label="Toggle Theme"
      >
        {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
      </button>

      {/* Hero Section */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center h-screen px-6">
        <motion.h1
          className="text-4xl md:text-6xl font-extrabold text-primary dark:text-white drop-shadow mb-6 max-w-4xl"
          initial={{ opacity: 0, y: -40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          AI-Powered Visual Learning Platform
        </motion.h1>
        <motion.p
          className="text-lg md:text-xl text-muted-foreground dark:text-gray-300 max-w-2xl mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2 }}
        >
          Instantly generate visuals, explanations, and quizzes tailored to your subject. Accelerate your studies with AI.
        </motion.p>
        <motion.div
          className="flex gap-4"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.4 }}
        >
          <button
            onClick={() => navigate('/signup')}
            className="bg-primary text-white px-6 py-3 rounded-lg text-lg shadow hover:bg-primary/90"
          >
            Get Started
          </button>
          <button
            onClick={() => navigate('/login')}
            className="text-primary border border-primary px-6 py-3 rounded-lg text-lg hover:bg-primary/10"
          >
            Login
          </button>
        </motion.div>
      </div>

      <FeatureSection />
      <RoadmapSection />
      <Footer />
    </div>
  );
}