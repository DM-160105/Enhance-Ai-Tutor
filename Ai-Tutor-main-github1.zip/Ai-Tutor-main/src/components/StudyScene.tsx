import { Canvas, useFrame } from '@react-three/fiber';
import { Suspense, useRef, useState } from 'react';
import * as THREE from 'three';

function FloatingMesh({ children, position, label }: { children: React.ReactNode; position: [number, number, number]; label: string }) {
  const ref = useRef<THREE.Mesh>(null!);
  const [hovered, setHovered] = useState(false);

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    ref.current.rotation.y = t * 0.5;
    ref.current.position.y = position[1] + Math.sin(t) * 0.2;
  });

  return (
    <group>
      <mesh
        ref={ref}
        position={position}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        {children}
        <meshStandardMaterial color={hovered ? '#facc15' : '#60a5fa'} />
      </mesh>
      <mesh position={[position[0], position[1] - 1, position[2]]}>
        <textGeometry args={[label, { size: 0.2, height: 0.05 }]} />
        <meshBasicMaterial color="white" />
      </mesh>
    </group>
  );
}

export default function StudyScene() {
  return (
    <Canvas
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        zIndex: -1,
        pointerEvents: 'none',
      }}
      camera={{ position: [0, 0, 8], fov: 50 }}
      shadows
    >
      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 5, 5]} intensity={1.5} castShadow />
      <Suspense fallback={null}>
        <FloatingMesh position={[-3, 0, 0]} label="Book">
          <boxGeometry args={[1.2, 0.2, 0.8]} />
        </FloatingMesh>
        <FloatingMesh position={[0, 0, 0]} label="Brain">
          <sphereGeometry args={[0.6, 32, 32]} />
        </FloatingMesh>
        <FloatingMesh position={[3, 0, 0]} label="Globe">
          <sphereGeometry args={[0.7, 32, 32]} />
        </FloatingMesh>
      </Suspense>
    </Canvas>
  );
}