import { motion } from 'framer-motion';
import { CalendarCheck, NotebookText, Sparkles } from 'lucide-react';

const roadmapItems = [
  {
    icon: <NotebookText className="w-6 h-6 text-primary" />,
    title: 'Notebook Feature',
    description: 'Save and organize all generated visuals and explanations into a personal study notebook.'
  },
  {
    icon: <CalendarCheck className="w-6 h-6 text-primary" />,
    title: 'Quiz Mode',
    description: 'Practice what you’ve learned with instant flashcards and AI-generated quizzes.'
  },
  {
    icon: <Sparkles className="w-6 h-6 text-primary" />,
    title: 'Collaboration Tools',
    description: 'Create shared study spaces with peers and teachers for collaborative learning.'
  }
];

export default function RoadmapSection() {
  return (
    <section className="relative z-10 py-20 bg-background px-6 md:px-12">
      <motion.h2
        className="text-3xl md:text-5xl font-bold text-center text-foreground mb-12"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
      >
        What’s Coming Next
      </motion.h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {roadmapItems.map((item, index) => (
          <motion.div
            key={index}
            className="bg-secondary/10 p-6 rounded-lg text-center shadow hover:shadow-md transition"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            viewport={{ once: true }}
          >
            <div className="mb-4 flex justify-center">{item.icon}</div>
            <h3 className="text-xl font-semibold text-foreground mb-2">{item.title}</h3>
            <p className="text-muted-foreground text-sm">{item.description}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}