import { motion } from 'framer-motion';
import { Lightbulb, BookOpen, Brain, CheckCircle } from 'lucide-react';

const features = [
  {
    icon: <BookOpen className="w-6 h-6 text-primary" />,
    title: 'Visual Explanations',
    description: 'Generate AI-powered illustrations to simplify complex concepts across all subjects.'
  },
  {
    icon: <Brain className="w-6 h-6 text-primary" />,
    title: 'AI-Generated Explanations',
    description: 'Receive topic-specific descriptions based on your selected subject and input.'
  },
  {
    icon: <Lightbulb className="w-6 h-6 text-primary" />,
    title: 'Conceptual Learning',
    description: 'Understand topics faster through visuals combined with concise learning points.'
  },
  {
    icon: <CheckCircle className="w-6 h-6 text-primary" />,
    title: 'Ready for All Subjects',
    description: 'Covers STEM, humanities, and more — just type a topic and let AI teach you.'
  },
];

export default function FeatureSection() {
  return (
    <section className="relative z-10 py-20 bg-background text-center px-6 md:px-12">
      <motion.h2
        className="text-3xl md:text-5xl font-bold text-foreground mb-12"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
      >
        What You’ll Get
      </motion.h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            className="bg-secondary/10 p-6 rounded-lg shadow hover:shadow-md transition"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            viewport={{ once: true }}
          >
            <div className="mb-4 flex justify-center">{feature.icon}</div>
            <h3 className="text-xl font-semibold text-foreground mb-2">{feature.title}</h3>
            <p className="text-muted-foreground text-sm">{feature.description}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}